#gastao_agrinho

Tema e Justificativa para o site:

  Nos últimos foi observado uma alta de taxa de pessoas com Epilepsia, principalmente em jovens, público mai atingido por essa doença.
  Foi pesquisado também mortes súbitas causados por essa doença no período noturno, daí que surge a necessidade de um "site" que ajude a população a tomar os devidos cuidados, para que se as mortes fossem evitadas, diminuindo a taxa de mortalidade por Epilepsia, aumentando a melhoraria da qualidade de vida e da qualidade do sono, e ficaria mais fácil o tratamento dessa condição, pois o monitoramento do sono é fundamental para a execução do tratamento.
